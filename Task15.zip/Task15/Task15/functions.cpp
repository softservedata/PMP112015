#include <iostream>
#include <vector>
#include "functions.h"
using namespace std;

vector<char> readGroup() {
	vector<char> group;
	int groupLength;
	do
	{
		cout << "Enter number of elements int the group:\n";
		cin >> groupLength;
		if (groupLength < 4 || groupLength > 50)
		{
			cout << "The group lenth must be between 4 and 50. ";
		}
	} while (groupLength < 4 || groupLength > 50);

	cout << "Enter " << groupLength << " elments:\n";
	char letter;
	for (int i = 0; i < groupLength; i++)
	{
		cin >> letter;
		group.push_back(letter);
	}

	return group;
}

void printGroup(vector<char> group) {
	
	if (group.size() > 0)
	{
		cout << "Displaying elements int the group:\n";

		for (int i = 0; i < group.size(); i++)
		{
			cout << group[i] << ' ';
		}

		cout << endl;
	}
	else
	{
		cout << "Group conntains no elements.\n";
	}	
}

vector<vector<char>> readGroups() {
	vector<vector<char>> groups;
	int groupsCount;
	
	do
	{
		cout << "Enter number of groups:\n";
		cin >> groupsCount;
		if (groupsCount < 2 || groupsCount > 10)
		{
			cout << "The groups count must be between 2 and 10. ";
		}
	} while (groupsCount < 2 || groupsCount > 10);

	for (int i = 0; i < groupsCount; i++)
	{
		vector<char> group = readGroup();
		groups.push_back(group);
	}

	return groups;
}

void printGroups(vector<vector<char>> groups) {
	for (int i = 0; i < groups.size(); i++)
	{
		printGroup(groups[i]);
	}
}

vector<char> findIntersect(vector<char> group1, vector<char> group2) {
	vector<char> intersect;
	for (int i = 0; i < group1.size(); i++)
	{
		for (int j = 0; j < group2.size(); j++)
		{
			if (group2[j] == group1[i])
			{
				bool exist = false;
				for (int z = 0; z < intersect.size(); z++)
				{
					if (intersect[z] == group1[i])
					{
						exist = true;
						break;
					}
				}

				if (!exist)
				{
					intersect.push_back(group1[i]);
				}					
			}
		}
	}

	return intersect;
}

vector<char> findIntersectInGroups(vector<vector<char>> groups)
{
	vector<char> intersect = groups[0];
	for (int i = 0; i < groups.size() - 1; i++)
	{
		intersect = findIntersect(intersect, groups[i + 1]);
	}

	return intersect;
}