#include <iostream>
#include <vector>
#include "functions.h"
using namespace std;

void main()
{
	vector<vector<char>> groups = readGroups();
	printGroups(groups);
	vector<char> intersect = findIntersectInGroups(groups);
	cout << "Intersected chars in the group. ";
	printGroup(intersect);
	char t;
	cin >> t;
}