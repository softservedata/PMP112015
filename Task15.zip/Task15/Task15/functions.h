#pragma once
#include <iostream>
#include <vector>
using namespace std;

vector<char> readGroup();
void printGroup(vector<char> group);

vector<vector<char>> readGroups();
void printGroups(vector<vector<char>> groups);

vector<char> findIntersect(vector<char> group1, vector<char> group2);
vector<char> findIntersectInGroups(vector<vector<char>> groups);